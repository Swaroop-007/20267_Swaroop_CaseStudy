﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Practical
{
    class UsingPeople
    {
        public static void Main()
        {

            try
            {
                TechnicalEmployee t1 = new TechnicalEmployee(123, "Swa", "Bangalore", 40000, new string[] { "py", "c++" });
                Console.WriteLine(t1.ToString());
                Console.WriteLine($"The salary of the staff {t1.name} is {t1.calculateSalary()}");

                Staff s1 = new Staff(456, "arp", "Mumbai", 8000, "Security");
                Console.WriteLine(s1.ToString());
                Console.WriteLine($"The salary of the staff {s1.name} is {s1.calculateSalary()}");
            }
            catch(ValueException)
            {
                throw new ValueException();
            }
            
        }
        class ValueException : Exception
        {
            public ValueException()
            {
                Console.WriteLine("Pleas Enter a valid Data");
            }
        }
    }
}
