﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Practical
{
    public class Staff : Employee // Sub class and inherits all the properties from base class
    {
        double salary;
        public Staff(int empid, string name, string address, double basicpay, string title)
            : base(empid, name, address, basicpay) // Inherits base class constructor
        {
            this.title = title;
        }

        public string title { get; set; }

        public override double calculateSalary()//Calculates salary of staff employee
        {
            double HRA = basicpay * (0.18);
            salary = HRA + basicpay;
            return salary;
        }
        public override string ToString()// overrides the method in other sub class when called
        {
            return $"The name of the Employee is {this.name} and the Employee Id is {this.empid} ";
        }

    }
}
