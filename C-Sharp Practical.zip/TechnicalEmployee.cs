﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Practical
{
    public class TechnicalEmployee : Employee // Sub class and inherits all the properties from base class
    {
        double salary;
        public TechnicalEmployee(int empid, string name, string address, double basicpay, string[] skills) 
            : base(empid, name, address, basicpay)// Inherits base class constructor
        {
            this.skills = skills;
        }
        public string[] skills { get; set; }

        public override double calculateSalary()//calculates the salary of technical employee
        {
            double HRA = basicpay * (0.12);
            salary = HRA + basicpay;
            return salary;
        }
        public string getSkills(string[] skills)
        {
            return $"Skills = {string.Join(',', skills)}";
        }
        public override string ToString()//Overrides the string in other sub-class
        {
            return $"The name of the Employee is {this.name} and the Employee Id is {this.empid} ";
        }
    }
}
