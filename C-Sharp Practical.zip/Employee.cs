﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Practical
{
    public abstract class Employee
    {
        public Employee(int empid,string name, string address,double basicpay)// Base class Constructor
        {
            this.empid = empid;
            this.name = name;
            this.address = address;
            this.basicpay = basicpay;
        }
        /* Using auto-implemetation getters and 
           setters we have declared variables below */
        public int empid { get; set; }
        public string name { get; set; }
        public string address { get; set; }
        public double basicpay { get; set; }

        public abstract double calculateSalary();// An abstract method that will be overriden in subclasses


    }
    

    

}
