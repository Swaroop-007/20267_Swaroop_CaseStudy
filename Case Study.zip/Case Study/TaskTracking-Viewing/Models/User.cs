﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TaskTracking_Viewing.Models
{
    public class User
    {
        public int UserID { get; set; }

        public string username { get; set; }
        public string email { get; set; }
        public string First_Name { get; set; }
        public string Last_name { get; set; }
        public int contact_number { get; set; }
        public string role { get; set; }
        public bool isActive { get; set; }

        public DateTime Dob { get; set; }

        public DateTime created_on { get; set; }
    }
}
