﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity.Models;

namespace Contracts
{
    public interface ITaskRepository
    {
        void Addtask(TaskCreation tname);

        void Removetask(TaskCreation tname);

        void Edittask(TaskCreation tname);

        IEnumerable<TaskCreation> Get();

        TaskCreation GetTask(int id);
    }
}
