﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Entity.Models;
using Contracts;

namespace Repository
{
    public class UserRepo :IUserRepository
    {
        static List<User> users { get; set; }
        static UserRepo()
        {
            users = new List<User>();
        }
        public void AddUser(User name)
        {
            users.Add(name);
        }

        public void RemoveUser(User name)
        {
            users.Remove(name);
        }

        public void EditUser(User name)
        {
            User user = users.FirstOrDefault(x => x.UserID == name.UserID);
            if (user != null)
            {
                user.username = name.username;
                user.email = name.email;
                user.First_Name = name.First_Name;
                user.Last_name = name.Last_name;
                user.contact_number = name.contact_number;
                user.role = name.role;
                user.isActive = name.isActive;
                user.Dob = name.Dob;
            }
        }

        public IEnumerable<User> get() => users;
       

        public User GetUser(int id)
        {
            User user = users.FirstOrDefault(x => x.UserID == id);
            return user;
        }
    }
}
