﻿using System;

namespace Repository
{
    public class Class1
    {
    }
}
