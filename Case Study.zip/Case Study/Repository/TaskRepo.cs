﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Entity.Models;
using Contracts;

namespace Repository
{
    public class TaskRepo : ITaskRepository
    {
        static List<TaskCreation> tasks { get; set; }

        static TaskRepo()
        {
            tasks = new List<TaskCreation>();
        }

        public void Addtask(TaskCreation tname)
        {
            tasks.Add(tname);
        }

        public void Removetask(TaskCreation tname)
        {
            tasks.Remove(tname);
        }

        public void Edittask(TaskCreation tname)
        {
            TaskCreation task = tasks.FirstOrDefault(x => x.TaskId == tname.TaskId);
            if (task != null)
            {
                task.TaskId = tname.TaskId;
                task.name = tname.name;
                task.description = tname.description;
                task.status = tname.status;
                task.priority = tname.priority;
                task.notes = tname.notes;
                task.bookmark = tname.bookmark;
                task.ownerid = tname.ownerid;
                task.creatorid = tname.creatorid;
                task.createdon = tname.createdon;
                task.modifiedon = tname.modifiedon;

            }
        }

        public IEnumerable<TaskCreation> Get() => tasks;
        

        public TaskCreation GetTask(int id)
        {
            TaskCreation task = tasks.FirstOrDefault(x => x.TaskId == id);
            return task;
        }
    }
}
