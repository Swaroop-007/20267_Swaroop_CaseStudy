﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using TaskTracking_MVC.Models;

namespace TaskTracking_MVC.Controllers
{
    public class TaskController : Controller
    {
        public async Task<IActionResult> Index()
        {
            List<TaskCreation> task = new List<TaskCreation>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("https://localhost:44322/api/Task"))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    task = JsonConvert.DeserializeObject<List<TaskCreation>>(apiResponse);
                }
                //
            }
            return View(task);
        }

        public ViewResult GetTask() => View();

        [HttpPost]
        public async Task<IActionResult> GetTask(int id)
        {
            TaskCreation task = new TaskCreation();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("https://localhost:44322/api/Task/" + id))
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        task = JsonConvert.DeserializeObject<TaskCreation>(apiResponse);
                    }
                    else
                        ViewBag.StatusCode = response.StatusCode;
                }
            }
            return View(task);
        }

        // GET: UserController/Create


        // POST: UserController/Create
        public ViewResult Addtask() => View();
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Addtask(TaskCreation task)
        {
            TaskCreation receivedtask = new TaskCreation();
            using (var httpClient = new HttpClient())
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(task), Encoding.UTF8, "application/json");

                using (var response = await httpClient.PostAsync("https://localhost:44322/api/Task", content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    receivedtask = JsonConvert.DeserializeObject<TaskCreation>(apiResponse);
                }
            }
            return View(receivedtask);
        }

        // GET: UserController/Edit/5
        public async Task<IActionResult> UpdateTask(int id)
        {
            TaskCreation tasks = new TaskCreation();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("https://localhost:44322/api/Task/" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    tasks = JsonConvert.DeserializeObject<TaskCreation>(apiResponse);
                }
            }
            return View(tasks);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateTask(TaskCreation tasks)
        {
            TaskCreation receivedtask = new TaskCreation();
            using (var httpClient = new HttpClient())
            {
                var content = new MultipartFormDataContent();
                content.Add(new StringContent(tasks.TaskId.ToString()), "TaskId");
                content.Add(new StringContent(tasks.name), "name");
                content.Add(new StringContent(tasks.status), "status");
                content.Add(new StringContent(tasks.priority.ToString()), "Priority");
                content.Add(new StringContent(tasks.notes), "notes");
                content.Add(new StringContent(tasks.bookmark), "role");
                content.Add(new StringContent(tasks.ownerid.ToString()), "ownerid");
                content.Add(new StringContent(tasks.creatorid.ToString()), "creatorid");
                content.Add(new StringContent(tasks.createdon.ToString()), "createdon");
                content.Add(new StringContent(tasks.modifiedon.ToString()), "modifiedon");
                //task.TaskId = tname.TaskId;
                //task.name = tname.name;
                //task.description = tname.description;
                //task.status = tname.status;
                //task.priority = tname.priority;
                //task.notes = tname.notes;
                //task.bookmark = tname.bookmark;
                //task.ownerid = tname.ownerid;
                //task.creatorid = tname.creatorid;
                //task.createdon = tname.createdon;
                //task.modifiedon = tname.modifiedon;

                using (var response = await httpClient.PutAsync("https://localhost:44322/api/Task", content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    ViewBag.Result = "Success";
                    receivedtask = JsonConvert.DeserializeObject<TaskCreation>(apiResponse);
                }
            }
            return View(receivedtask);
        }

        // GET: UserController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: UserController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
