﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using TaskTracking_MVC.Models;
using System.Net.Http;
using System.Text;

namespace TaskTracking_MVC.Controllers
{
    public class UserController : Controller
    {
        // GET: UserController
        public async Task<IActionResult> Index()
        {
            List<User> user = new List<User>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("https://localhost:44322/api/User"))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    user = JsonConvert.DeserializeObject<List<User>>(apiResponse);
                }
                //
            }
            return View(user);
        }

        public ViewResult GetUser() => View();

        [HttpPost]
        public async Task<IActionResult> GetUser(int id)
        {
            User user = new User();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("https://localhost:44322/api/User/" + id))
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        user = JsonConvert.DeserializeObject<User>(apiResponse);
                    }
                    else
                        ViewBag.StatusCode = response.StatusCode;
                }
            }
            return View(user);
        }

        // GET: UserController/Create


        // POST: UserController/Create
        public ViewResult AddUser() => View();
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Adduser(User user)
        {
            User receiveduser = new User();
            using (var httpClient = new HttpClient())
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(user), Encoding.UTF8, "application/json");

                using (var response = await httpClient.PostAsync("https://localhost:44322/api/User", content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    receiveduser = JsonConvert.DeserializeObject<User>(apiResponse);
                }
            }
            return View(receiveduser);
        }

        // GET: UserController/Edit/5
        public async Task<IActionResult> UpdateUser(int id)
        {
            User user = new User();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("https://localhost:44322/api/User/" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    user = JsonConvert.DeserializeObject<User>(apiResponse);
                }
            }
            return View(user);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateUser(User user)
        {
            User receiveduser = new User();
            using (var httpClient = new HttpClient())
            {
                var content = new MultipartFormDataContent();
                content.Add(new StringContent(user.UserID.ToString()), "UserID");
                content.Add(new StringContent(user.email), "email");
                content.Add(new StringContent(user.First_Name), "First_Name");
                content.Add(new StringContent(user.Last_name), "Last_name");
                content.Add(new StringContent(user.contact_number.ToString()), "contact_number");
                content.Add(new StringContent(user.role), "role");
                content.Add(new StringContent(user.isActive.ToString()), "isActive");
                content.Add(new StringContent(user.Dob.ToString()), "Dob");
                //user.username = name.username;
                //user.email = name.email;
                //user.First_Name = name.First_Name;
                //user.Last_name = name.Last_name;
                //user.contact_number = name.contact_number;
                //user.role = name.role;
                //user.isActive = name.isActive;
                //user.Dob = name.Dob;

                using (var response = await httpClient.PutAsync("https://localhost:44322/api/User", content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    ViewBag.Result = "Success";
                    receiveduser = JsonConvert.DeserializeObject<User>(apiResponse);
                }
            }
            return View(receiveduser);
        }

        // POST: UserController/Edit/5
       

        // GET: UserController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: UserController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
