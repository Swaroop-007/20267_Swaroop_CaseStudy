﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TaskTracking_MVC.Models
{
    public class TaskCreation
    {
        public int TaskId { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public string status { get; set; }
        public Priority priority { get; set; }
        public string notes { get; set; }
        public string bookmark { get; set; }
        public int ownerid { get; set; }
        public int creatorid { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime createdon { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime modifiedon { get; set; }
    }
    public enum Priority { High,Medium,Low}
}
//For Task
//taskid -int
//name - String
//description - String
//status - String
//priority - int
//notes - String
//bookmark - String
//ownerid int
//creatorid -int
//createdon - Date
//modifiedon - date