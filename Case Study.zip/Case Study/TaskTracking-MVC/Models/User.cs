﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TaskTracking_MVC.Models
{
    public class User
    {
        public int UserID { get; set; }

        public string username { get; set; }
        public string email { get; set; }
        public string First_Name { get; set; }
        public string Last_name { get; set; }
        public int contact_number { get; set; }
        public string role { get; set; }
        public Activity isActive { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime Dob { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime created_on { get; set; }
        public object Id { get; internal set; }
    }
    public enum Activity {Yes, No }

}
