﻿using Contracts;
using Entity.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TaskTracking_WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private IUserRepository repo;

        public UserController(IUserRepository Repo)
        {
            repo = Repo;
        }
        // GET: api/<UserController>
        [HttpGet]
        public IEnumerable<User> Get() => repo.get();
        

        // GET api/<UserController>/5
        [HttpGet("{id}")]
        public ActionResult<User> Get(int id)
        {
            return Ok(repo.GetUser(id));
            
        }

        // POST api/<UserController>
        [HttpPost]
        public void Post([FromBody] User name) => repo.AddUser(name);

        // PUT api/<UserController>/5
        [HttpPut("{id}")]
        public void Put([FromBody] User name)
        {
            repo.EditUser(name);
        }

        // DELETE api/<UserController>/5
        [HttpDelete("{id}")]
        public void Delete(User name)
        {
            repo.RemoveUser(name);
        }
    }
}
