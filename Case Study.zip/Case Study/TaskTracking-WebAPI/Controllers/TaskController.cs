﻿using Contracts;
using Entity.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TaskTracking_WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskController : ControllerBase
    {
        private ITaskRepository repo;

        public TaskController(ITaskRepository Repo)
        {
            repo = Repo;
        }

        // GET: api/<TaskController>
        [HttpGet]
        public IEnumerable<TaskCreation> Get() => repo.Get();

        // GET api/<TaskController>/5
        [HttpGet("{id}")]
        public ActionResult<TaskCreation> Get(int id)
        {
            return Ok(repo.GetTask(id));

        }

        // POST api/<TaskController>
        [HttpPost]
        public void Post([FromBody] TaskCreation name) => repo.Addtask(name);

        // PUT api/<TaskController>/5
        [HttpPut("{id}")]
        public void Put([FromBody] TaskCreation name)
        {
            repo.Edittask(name);
        }

        // DELETE api/<TaskController>/5
        [HttpDelete("{id}")]
        public void Delete(TaskCreation name)
        {
            repo.Removetask(name);
        }
    }
}
